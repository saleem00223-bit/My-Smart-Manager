# My Smart Manager (Flutter Android starter)

This ZIP contains the app source files and Android manifest changes. It is not a complete generated Flutter platform project and it is not a compiled APK.

## Create the Android project
1. Install Flutter SDK and Android Studio on a computer.
2. In a terminal, run:
   flutter create --platforms android my_smart_manager
3. Copy the `lib/` folder and `pubspec.yaml` from this ZIP into the generated `my_smart_manager/` folder, replacing the generated files.
4. Merge the permissions and application label from this ZIP's `android/app/src/main/AndroidManifest.xml` into the generated manifest. Keep the generated Flutter activity and other generated manifest entries.
5. Run these commands from the generated project folder:
   flutter pub get
   flutter doctor
   flutter build apk --release
6. The APK will be created at:
   build/app/outputs/flutter-apk/app-release.apk

## Included in this starter
- Material 3 Android-style interface
- PIN creation and PIN unlock
- Fingerprint/biometric unlock where supported by the device
- Offline SQLite storage for tasks, reminders, income/expenses, and document references
- Document picker
- Dashboard overview

## Important current limitations
- This is source code, not a compiled APK.
- Cloud backup is not configured. It needs a Firebase project (or another backup provider), app credentials, and a tested restore flow.
- Reminders are saved locally, but scheduled Android notifications are not yet implemented.
- Calendar screen is a placeholder for event scheduling.
- Document entries store local file paths. They do not yet copy files into app-private storage or encrypt uploaded files.
- Fingerprint unlock is device-dependent. A device must have biometrics enrolled and Android biometric permissions configured.
- PIN recovery/reset and app-data encryption need additional hardening before real personal or sensitive data is stored.

## Recommended next engineering steps
1. Add scheduled notifications with timezone handling and Android 13+ notification permission.
2. Copy selected documents into app-private storage and encrypt them.
3. Configure Firebase Authentication and Cloud Firestore/Storage for encrypted backup and restore.
4. Add transaction summaries, monthly filters, export to CSV/PDF, and calendar events.
5. Add PIN change/reset, biometric capability checks, and security testing.

Do not store official, confidential, or sensitive records in this starter build until security, backup, and restore have been reviewed and tested.
