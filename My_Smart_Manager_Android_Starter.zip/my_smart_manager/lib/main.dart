import 'package:flutter/material.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart' as p;
import 'package:local_auth/local_auth.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:file_picker/file_picker.dart';
import 'package:intl/intl.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await AppDb.instance.init();
  runApp(const MySmartManagerApp());
}

class AppDb {
  AppDb._();
  static final instance = AppDb._();
  late Database db;

  Future<void> init() async {
    final path = p.join(await getDatabasesPath(), 'my_smart_manager.db');
    db = await openDatabase(path, version: 1, onCreate: (d, _) async {
      await d.execute('CREATE TABLE tasks(id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, done INTEGER NOT NULL DEFAULT 0)');
      await d.execute('CREATE TABLE reminders(id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, due TEXT)');
      await d.execute('CREATE TABLE transactions(id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, amount REAL NOT NULL, kind TEXT NOT NULL, created TEXT NOT NULL)');
      await d.execute('CREATE TABLE documents(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, path TEXT NOT NULL, added TEXT NOT NULL)');
    });
  }

  Future<List<Map<String, Object?>>> all(String table) => db.query(table, orderBy: 'id DESC');
  Future<int> add(String table, Map<String, Object?> values) => db.insert(table, values);
  Future<int> update(String table, int id, Map<String, Object?> values) => db.update(table, values, where: 'id=?', whereArgs: [id]);
  Future<int> remove(String table, int id) => db.delete(table, where: 'id=?', whereArgs: [id]);
}

class MySmartManagerApp extends StatelessWidget {
  const MySmartManagerApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'My Smart Manager',
    debugShowCheckedModeBanner: false,
    theme: ThemeData(colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF24558A)), useMaterial3: true),
    home: const GatePage(),
  );
}

class GatePage extends StatefulWidget {
  const GatePage({super.key});
  @override
  State<GatePage> createState() => _GatePageState();
}

class _GatePageState extends State<GatePage> {
  final auth = LocalAuthentication();
  final secure = const FlutterSecureStorage();
  final pin = TextEditingController();
  bool hasPin = false;
  bool busy = false;
  String message = '';

  @override
  void initState() {
    super.initState();
    secure.read(key: 'app_pin').then((v) {
      if (mounted) setState(() => hasPin = v != null);
    });
  }

  Future<void> enter() async {
    setState(() { busy = true; message = ''; });
    try {
      if (!hasPin) {
        if (pin.text.length < 4) throw Exception('Choose a PIN with at least 4 digits.');
        await secure.write(key: 'app_pin', value: pin.text);
        if (!mounted) return;
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const HomePage()));
        return;
      }
      final saved = await secure.read(key: 'app_pin');
      if (pin.text == saved) {
        if (!mounted) return;
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const HomePage()));
      } else {
        setState(() => message = 'Incorrect PIN. Try again.');
      }
    } catch (e) {
      setState(() => message = e.toString().replaceFirst('Exception: ', ''));
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> biometric() async {
    try {
      final ok = await auth.authenticate(localizedReason: 'Unlock My Smart Manager');
      if (ok && mounted) Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const HomePage()));
    } catch (_) {
      setState(() => message = 'Biometric authentication is unavailable. Use your PIN.');
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    body: SafeArea(child: Center(child: SingleChildScrollView(padding: const EdgeInsets.all(24), child: Column(
      mainAxisAlignment: MainAxisAlignment.center, children: [
        const CircleAvatar(radius: 38, child: Icon(Icons.dashboard_rounded, size: 40)),
        const SizedBox(height: 18),
        const Text('My Smart Manager', style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        Text(hasPin ? 'Enter your PIN to continue' : 'Create a PIN to protect your app', style: const TextStyle(color: Colors.grey)),
        const SizedBox(height: 24),
        TextField(controller: pin, obscureText: true, keyboardType: TextInputType.number, maxLength: 8, decoration: const InputDecoration(labelText: 'PIN', border: OutlineInputBorder())),
        if (message.isNotEmpty) Padding(padding: const EdgeInsets.only(bottom: 12), child: Text(message, style: const TextStyle(color: Colors.red))),
        SizedBox(width: double.infinity, child: FilledButton(onPressed: busy ? null : enter, child: Text(busy ? 'Please wait...' : hasPin ? 'Unlock' : 'Create PIN'))),
        const SizedBox(height: 8),
        TextButton.icon(onPressed: hasPin ? biometric : null, icon: const Icon(Icons.fingerprint), label: const Text('Use fingerprint')),
        const SizedBox(height: 12),
        const Text('Your PIN is stored securely on this device.', style: TextStyle(fontSize: 12, color: Colors.grey)),
      ],
    )))),
  );
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int index = 0;
  final pages = const [DashboardTab(), TasksTab(), RemindersTab(), MoneyTab(), DocumentsTab(), CalendarTab()];
  final titles = const ['Dashboard', 'Tasks', 'Reminders', 'Income & Expenses', 'Documents', 'Calendar'];

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text(titles[index]), actions: [
      IconButton(tooltip: 'Lock app', onPressed: () => Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const GatePage())), icon: const Icon(Icons.lock_outline))
    ]),
    body: pages[index],
    bottomNavigationBar: NavigationBar(selectedIndex: index, onDestinationSelected: (v) => setState(() => index = v), destinations: const [
      NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
      NavigationDestination(icon: Icon(Icons.checklist), label: 'Tasks'),
      NavigationDestination(icon: Icon(Icons.notifications_none), label: 'Reminders'),
      NavigationDestination(icon: Icon(Icons.account_balance_wallet_outlined), label: 'Money'),
      NavigationDestination(icon: Icon(Icons.folder_outlined), label: 'Files'),
      NavigationDestination(icon: Icon(Icons.calendar_month_outlined), label: 'Calendar'),
    ]),
  );
}

class DashboardTab extends StatefulWidget {
  const DashboardTab({super.key});
  @override
  State<DashboardTab> createState() => _DashboardTabState();
}
class _DashboardTabState extends State<DashboardTab> {
  Future<List<Map<String,Object?>>> load() async => Future.wait([
    AppDb.instance.all('tasks'), AppDb.instance.all('transactions'), AppDb.instance.all('reminders')
  ]).then((v) => [...v[0], {'_expenses': v[1].where((e)=>e['kind']=='Expense').fold<double>(0, (s,e)=>s+(e['amount'] as num).toDouble())}, {'_reminders':v[2].length}]);
  @override
  Widget build(BuildContext context) => FutureBuilder<List<Map<String,Object?>>>(future: load(), builder: (c,s) {
    if (!s.hasData) return const Center(child:CircularProgressIndicator());
    final rows=s.data!;
    final tasks=rows.where((e)=>e.containsKey('done')).toList();
    final done=tasks.where((e)=>e['done']==1).length;
    final expense=rows.firstWhere((e)=>e.containsKey('_expenses'))['_expenses'] as double;
    final reminders=rows.firstWhere((e)=>e.containsKey('_reminders'))['_reminders'];
    return ListView(padding: const EdgeInsets.all(16), children: [
      Container(padding: const EdgeInsets.all(20), decoration: BoxDecoration(color: Theme.of(context).colorScheme.primaryContainer, borderRadius: BorderRadius.circular(20)), child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('Welcome back', style: TextStyle(fontSize: 23, fontWeight: FontWeight.bold)),
        SizedBox(height: 5), Text('Your personal life, organised in one place.')
      ])),
      const SizedBox(height: 16),
      Row(children: [
        _stat('Tasks', '${tasks.length}', Icons.check_circle_outline),
        _stat('Completed', '$done', Icons.done_all),
        _stat('Reminders', '$reminders', Icons.notifications_none),
      ]),
      const SizedBox(height: 12),
      Card(child: ListTile(leading: const Icon(Icons.payments_outlined), title: const Text('Recorded expenses'), trailing: Text(NumberFormat.currency(locale:'en_IN',symbol:'₹').format(expense), style: const TextStyle(fontWeight: FontWeight.bold)))),
      const Padding(padding: EdgeInsets.symmetric(vertical: 12), child: Text('Quick tip', style: TextStyle(fontWeight: FontWeight.bold))),
      const Text('Use the navigation bar to manage tasks, reminders, transactions and documents. Your entries are stored locally on this phone.')
    ]);
  });
  Widget _stat(String label,String value,IconData icon)=>Expanded(child: Card(child: Padding(padding: const EdgeInsets.all(12),child: Column(children:[Icon(icon),const SizedBox(height:6),Text(value,style: const TextStyle(fontSize:20,fontWeight:FontWeight.bold)),Text(label,style: const TextStyle(fontSize:12))]))));
}

class TasksTab extends StatefulWidget { const TasksTab({super.key}); @override State<TasksTab> createState()=>_TasksTabState(); }
class _TasksTabState extends State<TasksTab> {
  final ctl=TextEditingController();
  Future<void> add() async { if(ctl.text.trim().isEmpty)return; await AppDb.instance.add('tasks',{'title':ctl.text.trim(),'done':0}); ctl.clear(); setState((){}); }
  @override Widget build(BuildContext context)=>Column(children:[
    Padding(padding:const EdgeInsets.all(12),child:Row(children:[Expanded(child:TextField(controller:ctl,decoration:const InputDecoration(hintText:'Add a task',border:OutlineInputBorder()))),const SizedBox(width:8),IconButton.filled(onPressed:add,icon:const Icon(Icons.add))])),
    Expanded(child:FutureBuilder(future:AppDb.instance.all('tasks'),builder:(c,s)=>!s.hasData?const Center(child:CircularProgressIndicator()):ListView(children:s.data!.map((e)=>CheckboxListTile(value:e['done']==1,title:Text(e['title'] as String,style:TextStyle(decoration:e['done']==1?TextDecoration.lineThrough:null)),onChanged:(v)async{await AppDb.instance.update('tasks',e['id'] as int,{'done':v==true?1:0});setState((){});},secondary:IconButton(icon:const Icon(Icons.delete_outline),onPressed:()async{await AppDb.instance.remove('tasks',e['id'] as int);setState((){});}))).toList()))),
  ]);
}

class RemindersTab extends StatefulWidget { const RemindersTab({super.key}); @override State<RemindersTab> createState()=>_RemindersTabState(); }
class _RemindersTabState extends State<RemindersTab>{
  final ctl=TextEditingController();
  Future<void> add()async{if(ctl.text.trim().isEmpty)return;await AppDb.instance.add('reminders',{'title':ctl.text.trim(),'due':null});ctl.clear();setState((){});}
  @override Widget build(BuildContext context)=>Column(children:[
    Padding(padding:const EdgeInsets.all(12),child:Row(children:[Expanded(child:TextField(controller:ctl,decoration:const InputDecoration(hintText:'Reminder title',border:OutlineInputBorder()))),IconButton.filled(onPressed:add,icon:const Icon(Icons.add))])),
    Expanded(child:FutureBuilder(future:AppDb.instance.all('reminders'),builder:(c,s)=>!s.hasData?const Center(child:CircularProgressIndicator()):ListView(children:s.data!.map((e)=>ListTile(leading:const Icon(Icons.notifications_active_outlined),title:Text(e['title'] as String),trailing:IconButton(icon:const Icon(Icons.delete_outline),onPressed:()async{await AppDb.instance.remove('reminders',e['id'] as int);setState((){});}))).toList()))),
    const Padding(padding:EdgeInsets.all(12),child:Text('Timed notifications will be enabled in the next build.',style:TextStyle(color:Colors.grey,fontSize:12)))
  ]);
}

class MoneyTab extends StatefulWidget { const MoneyTab({super.key}); @override State<MoneyTab> createState()=>_MoneyTabState(); }
class _MoneyTabState extends State<MoneyTab>{
  final title=TextEditingController(),amount=TextEditingController(); String kind='Expense';
  Future<void> add()async{final n=double.tryParse(amount.text);if(title.text.trim().isEmpty||n==null||n<=0)return;await AppDb.instance.add('transactions',{'title':title.text.trim(),'amount':n,'kind':kind,'created':DateTime.now().toIso8601String()});title.clear();amount.clear();setState((){});}
  @override Widget build(BuildContext context)=>Column(children:[
    Padding(padding:const EdgeInsets.all(12),child:Column(children:[
      SegmentedButton<String>(segments:const [ButtonSegment(value:'Expense',label:Text('Expense')),ButtonSegment(value:'Income',label:Text('Income'))],selected:{kind},onSelectionChanged:(v)=>setState(()=>kind=v.first)),
      const SizedBox(height:8),TextField(controller:title,decoration:const InputDecoration(labelText:'Description',border:OutlineInputBorder())),
      const SizedBox(height:8),TextField(controller:amount,keyboardType:const TextInputType.numberWithOptions(decimal:true),decoration:const InputDecoration(labelText:'Amount (₹)',border:OutlineInputBorder())),
      const SizedBox(height:8),SizedBox(width:double.infinity,child:FilledButton(onPressed:add,child:const Text('Save transaction')))
    ])),
    Expanded(child:FutureBuilder(future:AppDb.instance.all('transactions'),builder:(c,s)=>!s.hasData?const Center(child:CircularProgressIndicator()):ListView(children:s.data!.map((e)=>ListTile(title:Text(e['title'] as String),subtitle:Text('${e['kind']} • ${DateFormat('d MMM yyyy').format(DateTime.parse(e['created'] as String))}'),trailing:Text('${e['kind']=='Expense'?'-':'+'}₹${(e['amount'] as num).toStringAsFixed(2)}',style:TextStyle(color:e['kind']=='Expense'?Colors.red:Colors.green,fontWeight:FontWeight.bold)),onLongPress:()async{await AppDb.instance.remove('transactions',e['id'] as int);setState((){});})).toList()))),
  ]);
}

class DocumentsTab extends StatefulWidget { const DocumentsTab({super.key}); @override State<DocumentsTab> createState()=>_DocumentsTabState(); }
class _DocumentsTabState extends State<DocumentsTab>{
  Future<void> pick()async{final result=await FilePicker.platform.pickFiles();if(result==null||result.files.single.path==null)return;await AppDb.instance.add('documents',{'name':result.files.single.name,'path':result.files.single.path!,'added':DateTime.now().toIso8601String()});setState((){});}
  @override Widget build(BuildContext context)=>Column(children:[
    Padding(padding:const EdgeInsets.all(12),child:SizedBox(width:double.infinity,child:FilledButton.icon(onPressed:pick,icon:const Icon(Icons.upload_file),label:const Text('Add a document')))),
    Expanded(child:FutureBuilder(future:AppDb.instance.all('documents'),builder:(c,s)=>!s.hasData?const Center(child:CircularProgressIndicator()):ListView(children:s.data!.map((e)=>ListTile(leading:const Icon(Icons.insert_drive_file_outlined),title:Text(e['name'] as String),subtitle:Text((e['path'] as String),maxLines:1,overflow:TextOverflow.ellipsis),trailing:IconButton(icon:const Icon(Icons.delete_outline),onPressed:()async{await AppDb.instance.remove('documents',e['id'] as int);setState((){});}))).toList()))),
    const Padding(padding:EdgeInsets.all(12),child:Text('Files are referenced locally. Back up original files separately until cloud backup is configured.',style:TextStyle(color:Colors.grey,fontSize:12)))
  ]);
}

class CalendarTab extends StatelessWidget {
  const CalendarTab({super.key});
  @override Widget build(BuildContext context)=>Center(child:Padding(padding:const EdgeInsets.all(24),child:Column(mainAxisSize:MainAxisSize.min,children:[
    const Icon(Icons.calendar_month,size:64),const SizedBox(height:12),const Text('Calendar',style:TextStyle(fontSize:22,fontWeight:FontWeight.bold)),
    Text(DateFormat('EEEE, d MMMM yyyy').format(DateTime.now())),
    const SizedBox(height:12),const Text('Calendar event scheduling and timed reminders are planned for the next build.',textAlign:TextAlign.center,style:TextStyle(color:Colors.grey))
  ])));
}
